$(document).ready(function(e) {

  // HEADER BURGER
  $('.header__burger').click(function(evant) {

    $('.header__burger,.header__content__media').toggleClass('active');
    $('body').toggleClass('lock');
  })
  //END HEADER BURGER
  // =====================================================
  // DROP DOWN
  $('.drop_arrow').click(function(e) {

    e.preventDefault();

    $('.drop_list, .drop_arrow').toggleClass('active');

  })

  // REMOVE CLASS ВНЕ БЛОКА

  $(document).mouseup(function(e) { // событие клика по веб-документу
    var div = $(".drop_arrow"); // тут указываем ID элемента
    if (!div.is(e.target) // если клик был не по нашему блоку
      &&
      div.has(e.target).length === 0) { // и не по его дочерним элементам
      $('.drop_list, .drop_arrow').removeClass('active'); // скрываем его
    }
  });
  //END REMOVE CLASS ВНЕ БЛОКА

  // =====================================================
  // PRODUCTIONS

  $('.bl_productions__items').slick({
    arrows: false,
    slidesToShow: 4,
    dots: true,
    slidesToScroll: 4,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [{
      breakpoint: 550,
      settings: {
        slidesToScroll: 2,
        slidesToShow: 2
      }
    }]
  });
  //END PRODUCTIONS
  // =====================================================
  // COMMUNITY

  $('.a_testimonials__items').slick({
    arrows: false,
    slidesToShow: 2,
    dots: true,
    slidesToScroll: 1,
    infinite: true,
    // autoplay: true,
    autoplaySpeed: 3000,
    responsive: [{
      breakpoint: 768,
      settings: {
        slidesToScroll: 1,
        slidesToShow: 1
      }
    }]
  });

  //END COMMUNITY
  // =====================================================



  // Block Our values
  let windowWidthTariff = $(window).width();
  if (windowWidthTariff <= 767) {

    $('.our_values__items').slick({
      arrows: true,
      slidesToShow: 3,
      dots: true,
      slidesToScroll: 1,
      infinite: true,
      responsive: [{
          breakpoint: 1200,
          settings: {
            slidesToShow: 2
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1
          }
        }
      ]
    });
  }

  //End Block Our values


  //END DROP DOWN
  // =====================================================

  // Block Our values
  // let windowWidthTariff = $(window).width();
  // if (windowWidthTariff <= 1560) {
  //
  //   $('.our_values__items').slick({
  //     arrows: true,
  //     slidesToShow: 3,
  //     dots: true,
  //     slidesToScroll: 1,
  //     infinite: true,
  //     responsive: [{
  //         breakpoint: 1200,
  //         settings: {
  //           slidesToShow: 2
  //         }
  //       },
  //       {
  //         breakpoint: 768,
  //         settings: {
  //           slidesToShow: 1
  //         }
  //       }
  //     ]
  //   });
  // }

  //End Block Our values

  // =====================================================
  // =====================================================

  // PAGE INDEX
  // -----------------------------------------------------
  // BLOCK SERVICES

  // if (windowWidthTariff <= 767) {
  //
  //   $('.our_services__items').slick({
  //     arrows: true,
  //     slidesToShow: 1,
  //     dots: true,
  //     slidesToScroll: 1,
  //     infinite: true
  //   });
  // }
  //END BLOCK SERVICES
  // -----------------------------------------------------
  // -----------------------------------------------------
  // OUR ACCREDITATIONS

  // if (windowWidthTariff <= 767) {
  //
  //   $('.bl_accreditations__slick').slick({
  //     arrows: true,
  //     slidesToShow: 1,
  //     dots: true,
  //     slidesToScroll: 1,
  //     infinite: true
  //   });
  // }
  // END OUR ACCREDITATIONS
  // -----------------------------------------------------
  // POPUP

  // $('.btn_popup').click(function(e) {
  //   e.preventDefault();
  //
  //   $('.bl_popup').css("display", "block").addClass("lock");
  //   $('body').addClass('lock');
  //
  // })
  //
  // $('.btn_close').click(function(evant) {
  //
  //   $('.bl_popup').css("display", "none").removeClass("lock");
  //
  //   $('body').removeClass('lock');
  //
  // })
  //END POPUP
  // -----------------------------------------------------
  // -----------------------------------------------------
  // END PAGE INDEX
  // =====================================================
  // =====================================================
  // PAGE HARD
  // -----------------------------------------------------
  // TESTIMONIALS
  // if (windowWidthTariff <= 991) {
  //
  //   $('.testimonials__items').slick({
  //     arrows: true,
  //     slidesToShow: 1,
  //     dots: false,
  //     slidesToScroll: 1,
  //     infinite: true
  //   });
  // }

  // END TESTIMONIALS
  // -----------------------------------------------------
  //END PAGE HARD
  // =====================================================
  // =====================================================
  // PAGE WHO ARE WE
  // -----------------------------------------------------
  // BLOCK ELEMENTS
  // if (windowWidthTariff <= 767) {
  //
  //   $('.elements__items').slick({
  //     arrows: true,
  //     slidesToShow: 1,
  //     dots: false,
  //     slidesToScroll: 1,
  //     infinite: true
  //   });
  // }
  // END BLOCK ELEMENTS
  // -----------------------------------------------------
  // END PAGE WHO ARE WE
  // =====================================================
  // =====================================================







})
