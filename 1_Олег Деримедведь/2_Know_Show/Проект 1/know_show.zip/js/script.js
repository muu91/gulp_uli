$(document).ready(function(e) {

  // $('a').click(function(e) {
  //   e.preventDefault();
  // })

  $('video').attr('autoplay', 'false');



  // HEADER BURGER
  $('.header__burger').click(function(evant) {

    $('.header__burger,.header__content__media').toggleClass('active');
    $('body').toggleClass('lock');
  })
  //END HEADER BURGER
  // =====================================================
  // DROP DOWN
  $('.drop_arrow').click(function(e) {

    e.preventDefault();

    $('.drop_list, .drop_arrow').this().toggleClass('active');

  })

  // END DROP DOWN
  // DROP DOWN MEDIA
  $('.drop_arrow__media').click(function(e) {

    $(this).next().slideToggle();

  })

  $('.drop_sub_arrow__media').click(function(e) {

    e.preventDefault();
    $(this).next().slideToggle(300);
  })

  //END DROP DOWN MEDIA


  // REMOVE CLASS ВНЕ БЛОКА

  $(document).mouseup(function(e) {
    var div = $(".drop_arrow");
    if (!div.is(e.target) // если клик был не по нашему блоку
      &&
      div.has(e.target).length === 0) { // и не по его дочерним элементам
      $('.drop_list, .drop_arrow').removeClass('active'); // скрываем его
    }
  });
  //END REMOVE CLASS ВНЕ БЛОКА

  // =====================================================
  // PRODUCTIONS

  $('.bl_productions__items').slick({
    arrows: false,
    slidesToShow: 4,
    dots: true,
    slidesToScroll: 4,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [{
      breakpoint: 550,
      settings: {
        slidesToScroll: 2,
        slidesToShow: 2
      }
    }]
  });
  //END PRODUCTIONS
  // =====================================================
  // COMMUNITY

  $('.bl_testimonials .a_testimonials__items').slick({
    arrows: false,
    slidesToShow: 2,
    dots: true,
    slidesToScroll: 1,
    infinite: true,
    // autoplay: true,
    autoplaySpeed: 3000,
    responsive: [{
      breakpoint: 768,
      settings: {
        slidesToScroll: 1,
        slidesToShow: 1
      }
    }]
  });

  //END COMMUNITY
  // =====================================================



  // Block Our values
  var windowWidthTariff = $(window).width();
  if (windowWidthTariff <= 767) {

    $('.our_values__items').slick({
      arrows: true,
      slidesToShow: 3,
      dots: true,
      slidesToScroll: 1,
      infinite: true,
      responsive: [{
          breakpoint: 1200,
          settings: {
            slidesToShow: 2
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1
          }
        }
      ]
    });
  }

  //End Block Our values


  //END DROP DOWN
  // =====================================================
  // =====================================================
  //PAGE PRODUCTIONS

  if (windowWidthTariff <= 767) {


    $('.bl_fall_behind .a_testimonials__items').slick({
      arrows: false,
      slidesToShow: 1,
      dots: true,
      slidesToScroll: 1,
      infinite: true,
      autoplaySpeed: 3000
    });
  }


  //END PAGE PRODUCTIONS
  // =====================================================
  // =====================================================
  // PAGE TEAM

  $('.a_for_img__items__slick1').slick({
    arrows: true,
    slidesToShow: 4,
    dots: true,
    slidesToScroll: 1,
    infinite: true,
    autoplaySpeed: 3000,
    responsive: [{
        breakpoint: 991,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1
        }
      }
    ]
  });

  // END PAGE TEAM
  // =====================================================
  // =====================================================

  // -----------------------------------------------------

  // POPUP INDEX

  $('.popup_btn_index').click(function(e) {
    e.preventDefault();

    $('.a_popup_service').css("display", "flex").addClass("lock");
    $('body').addClass('lock');

  })

  $('.btn_close_index').click(function(e) {

    e.preventDefault();

    $('.a_popup_service').css("display", "none").removeClass("lock");

    $('body').removeClass('lock');

  })
  // END POPUP INDEX
  // -----------------------------------------------------

  // POPUP TEAM

  var person = $("[data-person]");

  person.on("click", function(e) {
    e.preventDefault();
    var subPerson = $(this).data('person');
    $("[data-person_content]").each(function() {
      var personContent = $(this).data('person_content');
      if (personContent == subPerson) {
        $(this).css("display", "flex").addClass("lock");
        $('body').addClass('lock');
      } else {
        var closeTeam = $('.btn_close_team');
        closeTeam.on("click", function(e) {
          e.preventDefault();
          $('.a_popup_team').css("display", "none").removeClass("lock");
          $('body').removeClass('lock');
        });
      }
      if (personContent != subPerson) {
        $(this).css("display", "none").removeClass("lock");
        $('body').removeClass('lock');
      }
    });
  });

  var closeTeam = $('.btn_close_team');
  closeTeam.on("click", function(e) {
    e.preventDefault();
    $('.a_popup_team').css("display", "none").removeClass("lock");
    $('body').removeClass('lock');
  });
  //END POPUP TEAM

  // -----------------------------------------------------
  // -----------------------------------------------------
  // POPUP APP
  $('.register_app').click(function(e) {
    e.preventDefault();

    $('.a_popup_app').css("display", "flex").addClass("lock");
    $('body').addClass('lock');

  })

  $('.btn_close_app').click(function(e) {
    e.preventDefault();

    $('.a_popup_app').css("display", "none").removeClass("lock");

    $('body').removeClass('lock');

  })
  //END POPUP APP
  // -----------------------------------------------------

  // END PAGE INDEX
  // =====================================================
  // =====================================================
  // PAGE EPISODES
  // -----------------------------------------------------

  $(".btn__soc").click(function(e) {
    e.preventDefault();
    $('.btn__soc.btn__soc_active').removeClass('btn__soc_active');
    $(this).toggleClass('btn__soc_active');
  });

  var episodesBtn = $("[data-btn]");
  $(episodesBtn).click(function(e) {
    e.preventDefault();
    var aNavEpisodes = $(this).data('btn');
    $("[data-text]").each(function() {
      var episodesText = $(this).data('text');
      if (episodesText == aNavEpisodes) {
        $(this).slideToggle();
      } else {
        $(this).slideUp();
      }
    });
  });

  // EPISODE BTN MORE

  // var episodesItem = $(".a_episodes__item");
  // $(episodesItem).addClass("a_episodes__item__none");
  // $(episodesItem).slice(0, 5).addClass("a_episodes__item__flex");
  // $(".episodes__btn").on("click", function(e) {
  //   e.preventDefault();
  //   $(episodesItem).not('.a_episodes__item__flex').slice(0, 5).addClass("a_episodes__item__flex");
  // });

  //EPISODE  ENd BTN MORE

  // TESTIMONIALS

  // Item1

  $('.a_episodes__item > .a_episodes__item1').hover(function() {

      $('.a_episodes__item1 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item1 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item1 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item1 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );


  // Item2

  $('.a_episodes__item > .a_episodes__item2').hover(function() {

      $('.a_episodes__item2 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item2 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item2 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item2 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );

  // Item3

  $('.a_episodes__item > .a_episodes__item3').hover(function() {

      $('.a_episodes__item3 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item3 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item3 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item3 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );

  // Item4

  $('.a_episodes__item > .a_episodes__item4').hover(function() {

      $('.a_episodes__item4 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item4 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item4 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item4 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );

  // Item5

  $('.a_episodes__item > .a_episodes__item5').hover(function() {

      $('.a_episodes__item5 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item5 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item5 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item5 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );

  // END PAGE EPISODES
  // -----------------------------------------------------
  //END PAGE EPISODES
  // =====================================================
  // =====================================================
  // -----------------------------------------------------
  // PAGE BECOME A QUEST


  $(".a__tab_nav").first().addClass("active__tab_nav");
  $("[data-tab_content]").hide().first().show();

  $(".a__tab_nav").click(function(e) {
    e.preventDefault();

    $('.a__tab_nav.active__tab_nav').removeClass('active__tab_nav');
    $(this).addClass('active__tab_nav');
  });

  var tabNavBtn = $("[data-filter_tab]");
  tabNavBtn.on("click", function(e) {
    e.preventDefault();
    var tabNavBtnClick = $(this).data('filter_tab');
    $("[data-tab_content]").each(function() {
      var tabContent = $(this).data('tab_content');
      if (tabContent != tabNavBtnClick) {
        $(this).hide();
      } else {
        $(this).show();
      }
    });
  });


  //END PAGE BECOME A QUEST
  // -----------------------------------------------------
  // =====================================================
  // =====================================================

  // PAGE VIDEO
  // VIDEO FILTER

  $(".a__nav").first().addClass("active__nav");
  $(".a__nav").click(function(e) {
    e.preventDefault();
    $('.a__nav.active__nav').removeClass('active__nav');
    $(this).addClass('active__nav');
  });
  var filter = $("[data-filter]");
  filter.on("click", function(e) {
    e.preventDefault();
    var aNavCat = $(this).data('filter');
    $("[data-content]").each(function() {
      var videoContents = $(this).data('content');
      if (videoContents != aNavCat) {
        $(this).hide();
      } else {
        $(this).show();
      }
    });
  });

  $("[data-filter=research]").click();
  //END VIDEO FILTER


  var playVideosBtn = $(".videos__item");

  $(playVideosBtn).each(function() {
    $(playVideosBtn).on("click", function() {
      $(this).find("img, a").hide();
      // $(this).find("video").get().play();
    });
  });

  // $('.videos__item').click(function(e) {
  //   e.preventDefault();
  //   function() {
  //     var $('.videos_img, .play_videos').fade();
  //     $(this).hide();
  //   }
  // });
  //
  // $(".videos__subitem").show();
  // $(".videos__subitem").click(function() {
  //   // $(".soc .btn__soc").removeClass("btn__soc_active").eq($(this).index()).toggleClass("btn__soc_active");
  //   $(".videos_img").eq($(this).index()).hide();
  //   $(".play_videos").eq($(this).index()).hide();
  //
  //
  // });

  //
  // var size = 2;
  // var videoAcademics = $("[data-content=academics]");
  //
  //
  // $(".videos__item").each(function() {
  //
  //   if ($("[data-filter=research]").click()) {
  //     $(".videos__more").addClass("research__more");
  //   } else {
  //     $(".videos__more").removeClass("research__more");
  //   }
  //
  //   if ($("[data-filter=academics]").click()) {
  //     $(".videos__more").addClass("academics__more");
  //   } else {
  //     $(".videos__more").removeClass("academics__more");
  //   }
  //
  // });
  //
  //
  // $(videoAcademics).addClass("videos__item__none");
  // $("[data-content=academics]").slice(0, size).addClass("videos__item__block");
  //
  // $(".academics__more").on("click", function() {
  //   $("[data-content=academics]").not('.videos__item__block').slice(0, 2).addClass("videos__item__block");
  // });
  //
  // var videoResearch = $("[data-content=research]");
  //
  // $(videoResearch).addClass("videos__item__none");
  // $("[data-content=research]").slice(0, size).addClass("videos__item__block");
  //
  // $(".research__more").on("click", function() {
  //   $("[data-content=research]").not('.videos__item__block').slice(0, 2).addClass("videos__item__block");
  // });








  //END PAGE VIDEO

  // =====================================================
  // =====================================================
  // AUDIO
  // Audio INDEX
  var player1 = new Plyr('#player1', {
    controls: [
      'play',
      'progress',
      'current-time'
    ],
    invertTime: false
  });
  //END Audio INDEX

  // Audio Productions

  var player2 = new Plyr('#player2', {
    controls: [
      'play',
      'progress',
      'current-time'
    ],
    invertTime: false
  });

  var player3 = new Plyr('#player3', {
    controls: [
      'play',
      'progress',
      'current-time'
    ],
    invertTime: false
  });

  //End Audio Productions
  // END AUDIO
  // =====================================================
  // =====================================================
  // VIDEO

  $('.play_icon1').click(function() {
    $('#video1').css("z-index", "10");
  })

  $('.play_icon2').click(function() {
    $('#video2').css("z-index", "10");
  })

  $('.play_icon3').click(function() {
    $('#video3').css("z-index", "10");
  })

  $('.play_icon4').click(function() {
    $('#video4').css("z-index", "10");
  })

  $(".play_icon5").click(function() {
    $('.header_video__img, .header_video__text, .header_play').hide();
    $("#video5").css("z-index", "10");
  });

  $('.play_icon6').click(function() {
    $('#video6').css("z-index", "10");
  });
  // END VIDEO

});

// =====================================================
// =====================================================
//
// Clean JS
// Index Page

var video1 = document.getElementById("video1");
var video2 = document.getElementById("video2");
var video3 = document.getElementById("video3");
var video4 = document.getElementById("video4");
var video5 = document.getElementById("video5");
var video6 = document.getElementById("video6");

// PAGE VIDEO

var videos1 = document.getElementById("videos1");
var videos2 = document.getElementById("videos2");
var videos3 = document.getElementById("videos3");
var videos4 = document.getElementById("videos4");
var videos5 = document.getElementById("videos5");
var videos6 = document.getElementById("videos6");
var videos7 = document.getElementById("videos7");
var videos8 = document.getElementById("videos8");
var videos8 = document.getElementById("videos9");
var videos8 = document.getElementById("videos10");
var videos8 = document.getElementById("videos11");
var videos8 = document.getElementById("videos12");


//END PAGE VIDEO


// function playClip(media) {
//   media.play();
// }


function playClip(media) {
  if (media) {
    media.play();
  }
}
// playClip(video1);
// playClip(video2);
// playClip(video3);
// playClip(video4);
// playClip(video5);
// playClip(video6);
//
// // End Index Page
// // END Clean JS
//
// // PAGE VIDEO
// playClip(videos1);
// playClip(videos2);
// playClip(videos3);
// playClip(videos4);
// playClip(videos5);
// playClip(videos6);
// playClip(videos7);
// playClip(videos8);
// playClip(videos9);
// playClip(videos10);
// playClip(videos11);
// playClip(videos12);
//END PAGE VIDEO
