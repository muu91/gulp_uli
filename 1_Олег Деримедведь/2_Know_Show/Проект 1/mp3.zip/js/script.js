$(document).ready(function(e) {

  // HEADER BURGER
  $('.header__burger').click(function(evant) {

    $('.header__burger,.header__content__media').toggleClass('active');
    $('body').toggleClass('lock');
  })
  //END HEADER BURGER
  // =====================================================
  // DROP DOWN
  $('.drop_arrow').click(function(e) {

    e.preventDefault();

    $('.drop_list, .drop_arrow').toggleClass('active');
    // $('.drop_list').fadeToggle("slow");
  })

  // END DROP DOWN
  // DROP DOWN MEDIA
  $('.drop_arrow__media').click(function(e) {

    e.preventDefault();

    $('.drop_list__media').fadeToggle(300);
    // $('.drop_list').fadeToggle("slow");
  })

  //END DROP DOWN MEDIA


  // REMOVE CLASS ВНЕ БЛОКА

  $(document).mouseup(function(e) { // событие клика по веб-документу
    var div = $(".drop_arrow"); // тут указываем ID элемента
    if (!div.is(e.target) // если клик был не по нашему блоку
      &&
      div.has(e.target).length === 0) { // и не по его дочерним элементам
      $('.drop_list, .drop_arrow').removeClass('active'); // скрываем его
    }
  });
  //END REMOVE CLASS ВНЕ БЛОКА

  // =====================================================
  // PRODUCTIONS

  $('.bl_productions__items').slick({
    arrows: false,
    slidesToShow: 4,
    dots: true,
    slidesToScroll: 4,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [{
      breakpoint: 550,
      settings: {
        slidesToScroll: 2,
        slidesToShow: 2
      }
    }]
  });
  //END PRODUCTIONS
  // =====================================================
  // COMMUNITY

  $('.bl_testimonials .a_testimonials__items').slick({
    arrows: false,
    slidesToShow: 2,
    dots: true,
    slidesToScroll: 1,
    infinite: true,
    // autoplay: true,
    autoplaySpeed: 3000,
    responsive: [{
      breakpoint: 768,
      settings: {
        slidesToScroll: 1,
        slidesToShow: 1
      }
    }]
  });

  //END COMMUNITY
  // =====================================================



  // Block Our values
  let windowWidthTariff = $(window).width();
  if (windowWidthTariff <= 767) {

    $('.our_values__items').slick({
      arrows: true,
      slidesToShow: 3,
      dots: true,
      slidesToScroll: 1,
      infinite: true,
      responsive: [{
          breakpoint: 1200,
          settings: {
            slidesToShow: 2
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1
          }
        }
      ]
    });
  }

  //End Block Our values


  //END DROP DOWN
  // =====================================================
  // =====================================================
  //PAGE PRODUCTIONS

  if (windowWidthTariff <= 767) {


    $('.bl_fall_behind .a_testimonials__items').slick({
      arrows: false,
      slidesToShow: 1,
      dots: true,
      slidesToScroll: 1,
      infinite: true,
      autoplaySpeed: 3000
    });
  }


  //END PAGE PRODUCTIONS
  // =====================================================
  // =====================================================
  // PAGE TEAM

  $('.a_for_img__items__slick1').slick({
    arrows: true,
    slidesToShow: 4,
    dots: true,
    slidesToScroll: 1,
    infinite: true,
    autoplaySpeed: 3000,
    responsive: [{
        breakpoint: 991,
        settings: {
          slidesToShow: 3
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1
        }
      }
    ]
  });

  // END PAGE TEAM
  // =====================================================
  // =====================================================

  // -----------------------------------------------------

  // POPUP INDEX

  $('.popup_btn_index').click(function(e) {
    e.preventDefault();

    $('.a_popup_service').css("display", "flex").addClass("lock");
    $('body').addClass('lock');

  })

  $('.btn_close_index').click(function(e) {

    e.preventDefault();

    $('.a_popup_service').css("display", "none").removeClass("lock");

    $('body').removeClass('lock');

  })
  // END POPUP INDEX
  // -----------------------------------------------------

  // POPUP TEAM
  $('.person_info').click(function(e) {
    e.preventDefault();

    $('.a_popup_team').css("display", "flex").addClass("lock");
    $('body').addClass('lock');

  })

  $('.btn_close_team').click(function(e) {

    e.preventDefault();

    $('.a_popup_team').css("display", "none").removeClass("lock");

    $('body').removeClass('lock');

  })
  //END POPUP TEAM

  // -----------------------------------------------------
  // -----------------------------------------------------
  // POPUP APP
  $('.register_app').click(function(e) {
    e.preventDefault();

    $('.a_popup_app').css("display", "flex").addClass("lock");
    $('body').addClass('lock');

  })

  $('.btn_close_app').click(function(e) {

    e.preventDefault();

    $('.a_popup_app').css("display", "none").removeClass("lock");

    $('body').removeClass('lock');

  })
  //END POPUP APP
  // -----------------------------------------------------

  // END PAGE INDEX
  // =====================================================
  // =====================================================
  // PAGE EPISODES
  // -----------------------------------------------------
  // TESTIMONIALS

  // Item1

  $('.a_episodes__item > .a_episodes__item1').hover(function() {

      $('.a_episodes__item1 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item1 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item1 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item1 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );


  // Item2

  $('.a_episodes__item > .a_episodes__item2').hover(function() {

      $('.a_episodes__item2 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item2 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item2 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item2 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );

  // Item3

  $('.a_episodes__item > .a_episodes__item3').hover(function() {

      $('.a_episodes__item3 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item3 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item3 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item3 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );

  // Item4

  $('.a_episodes__item > .a_episodes__item4').hover(function() {

      $('.a_episodes__item4 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item4 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item4 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item4 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );

  // Item5

  $('.a_episodes__item > .a_episodes__item5').hover(function() {

      $('.a_episodes__item5 > .a_episodes__announce').css({
        "opacity": "0",
        "height": "0"
      }, 500);
      $('.a_episodes__item5 > .a_episodes__text').css({
        "opacity": "1",
        "height": "auto",
        "padding": "60px"
      }, 500);

    },
    function() {

      $('.a_episodes__item5 > .a_episodes__announce').css({
        "opacity": "1",
        "height": "auto"
      }, 500);
      $('.a_episodes__item5 > .a_episodes__text').css({
        "opacity": "0",
        "height": "0",
        "padding": "0"
      }, 500);

    }
  );




  // END PAGE EPISODES
  // -----------------------------------------------------
  //END PAGE EPISODES
  // =====================================================
  // =====================================================
  // PAGE WHO ARE WE
  // -----------------------------------------------------
  // BLOCK ELEMENTS
  // if (windowWidthTariff <= 767) {
  //
  //   $('.elements__items').slick({
  //     arrows: true,
  //     slidesToShow: 1,
  //     dots: false,
  //     slidesToScroll: 1,
  //     infinite: true
  //   });
  // }
  // END BLOCK ELEMENTS
  // -----------------------------------------------------
  // END PAGE WHO ARE WE
  // =====================================================
  // =====================================================


  var player = new Plyr('#player', {
    controls: [
        'play',
        'progress',
        'current-time'
    ],
    invertTime: false
});




})
