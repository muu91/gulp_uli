$(document).ready(function(e) {

  $('.header__burger, .header__menu').click(function(evant) {

    $('.header__burger,.header__menu').toggleClass('active');
    $('body').toggleClass('lock');
  })
  // Block Our values
  let windowWidthTariff = $(window).width();
  if (windowWidthTariff <= 1560) {

    $('.our_values__items').slick({
      arrows: true,
      slidesToShow: 3,
      dots: true,
      slidesToScroll: 1,
      infinite: true,
      responsive: [{
          breakpoint: 1200,
          settings: {
            slidesToShow: 2
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1
          }
        }
      ]
    });
  }

  //End Block Our values

  // =====================================================
  // =====================================================

  // PAGE INDEX
  // -----------------------------------------------------
  // BLOCK SERVICES

  if (windowWidthTariff <= 767) {

    $('.our_services__items').slick({
      arrows: true,
      slidesToShow: 1,
      dots: true,
      slidesToScroll: 1,
      infinite: true
    });
  }
  //END BLOCK SERVICES
  // -----------------------------------------------------
  // -----------------------------------------------------
  // OUR ACCREDITATIONS

  if (windowWidthTariff <= 767) {

    $('.bl_accreditations__slick').slick({
      arrows: true,
      slidesToShow: 1,
      dots: true,
      slidesToScroll: 1,
      infinite: true
    });
  }
  // END OUR ACCREDITATIONS
  // -----------------------------------------------------
  // POPUP

  $('.btn_popup').click(function(e) {
    e.preventDefault();

    $('.bl_popup').css("display", "block").addClass("lock");
      $('body').addClass('lock');

  })

  $('.btn_close').click(function(evant) {

    $('.bl_popup').css("display", "none").removeClass("lock");

    $('body').removeClass('lock');

  })
  //END POPUP
  // -----------------------------------------------------
  // -----------------------------------------------------
  // END PAGE INDEX
  // =====================================================
  // =====================================================
  // PAGE HARD
  // -----------------------------------------------------
  // TESTIMONIALS
  if (windowWidthTariff <= 991) {

    $('.testimonials__items').slick({
      arrows: true,
      slidesToShow: 1,
      dots: false,
      slidesToScroll: 1,
      infinite: true
    });
  }

  // END TESTIMONIALS
  // -----------------------------------------------------
  //END PAGE HARD
  // =====================================================
  // =====================================================
  // PAGE WHO ARE WE
  // -----------------------------------------------------
  // BLOCK ELEMENTS
  if (windowWidthTariff <= 767) {

    $('.elements__items').slick({
      arrows: true,
      slidesToShow: 1,
      dots: false,
      slidesToScroll: 1,
      infinite: true
    });
  }
  // END BLOCK ELEMENTS
  // -----------------------------------------------------
  // END PAGE WHO ARE WE
  // =====================================================
  // =====================================================







})
